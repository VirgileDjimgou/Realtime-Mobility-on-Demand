package com.android.gudana.BootNavigation;

import com.android.gudana.R;

/**
 * Created by crugnola on 11/28/16.
 * BottomNavigation
 */

public class MainActivityNoCoordinator extends MainActivity {
    @Override
    protected int getActivityLayoutResId() {
        return R.layout.bn_activity_main_no_coordinator;
    }
}
