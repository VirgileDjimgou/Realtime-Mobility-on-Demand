package com.android.gudana.BootNavigation;

import com.android.gudana.R;

/**
 * Created by crugnola on 4/12/16.
 */
public class MainActivityTabletCollapsedToolbar extends MainActivityTablet {
    @Override
    protected int getLayoutResId() {
        return R.layout.bn_activity_main_tablet_collapsing;
    }
}
