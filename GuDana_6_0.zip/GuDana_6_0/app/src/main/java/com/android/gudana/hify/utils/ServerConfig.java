package com.android.gudana.hify.utils;


import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.android.gudana.R;

import es.dmoral.toasty.Toasty;


public class ServerConfig  {

    public  static final String TAG = "MainActivity";

    // Remote Config keys
    public static final String LOADING_PHRASE_CONFIG_KEY = "loading_phrase";
    public static final String WELCOME_MESSAGE_KEY = "welcome_message";
    public static final String WELCOME_MESSAGE_CAPS_KEY = "welcome_message_caps";

    public static FirebaseRemoteConfig mFirebaseRemoteConfig;
    public static TextView mWelcomeTextView;


    // [END display_welcome_message]
}