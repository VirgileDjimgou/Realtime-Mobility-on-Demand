package com.android.gudana.chatapp.models;



public class StaticConfigUser_fromFirebase {
    public static String STR_USER_ID = "";
    public  static String  STR_USER_TOKEN_FCM = "";
    public static String STR_EXTRA_EMAIL= "email";
    public static String USER_NAME = "";
    public static String USER_URL_IMAGE = "";


    // get the  User dat  from the two Datatbase ..also  firebase and firestore  ...
    // save the User data as  a static  variable   ... in your db  ...
    public void getUserInfos_fromFirebase(String UserId){
        // so gettting the  user from firestore  ....


        // get the data from

    }
}
